



import UIKit

class NSNotificationReceiverViewController: UIViewController {
    
    var name = String()
    
    @IBOutlet weak var btnData: UIButton!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        NotificationCenter.default.addObserver(self, selector: #selector(Home(notification:)), name: .Home, object: nil)
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(Login(notification:)), name: .Login, object: nil)
        
    }
    
    @objc func Home(notification:Notification){
        
        print("Home")
        btnData.setTitle("Home", for: UIControl.State.normal)

    }
    
    @objc func Login(notification:Notification){
           
        print("Login")
        print(notification.name)
        print(notification.hashValue)
        
        guard let name = notification.userInfo!["name"] else { return }

        print(name)
        
        btnData.setTitle("Login", for: UIControl.State.normal)
        
    }
   

    @IBAction func actionToNavigate(_ sender: Any) {
        
        let notiVC = self.storyboard?.instantiateViewController(withIdentifier: "NSNotificationSenderViewController") as! NSNotificationSenderViewController
        self.navigationController?.pushViewController(notiVC, animated: true)
               
    }
    
//    override func viewDidDisappear(_ animated: Bool) {
//      super.viewDidDisappear(true)
//      NotificationCenter.default.removeObserver(self)
//    }
    
    
}

extension Notification.Name{
    
    static let Home = Notification.Name("Home")
    static let Login = Notification.Name("Login")
    
    
}
