
import UIKit

class NSNotificationSenderViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    @IBAction func actionHome(_ sender: Any) {
        
        NotificationCenter.default.post(name: .Home, object: nil)
        
        self.navigationController?.popViewController(animated: true)

    }
    
    
    @IBAction func actionLogin(_ sender: Any) {
            

        NotificationCenter.default.post(name: .Login, object: nil, userInfo: ["name":"Naminder kaur","address":"delhi"])

        self.navigationController?.popViewController(animated: true)

    }
    
    
   
    
}
